//
//  PdSettingsViewController.h
//  PdSettings
//
//  Created by Richard Eakin on 18/09/11.
//  Copyright 2011 Blarg. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PdBase.h"

@interface PdSettingsViewController : UIViewController <PdReceiverDelegate, UIPickerViewDelegate, UIPickerViewDataSource>

@end
