//
//  DispatcherSampleTests.h
//  DispatcherSampleTests
//
//  Created by Peter Brinkmann on 8/28/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>


@interface DispatcherSampleTests : SenTestCase {
@private
    
}

@end
